package com.mercury.onAccident;

import java.util.ArrayList;
import java.util.TreeMap;

public class SearchGoogle {

	
	
	public String findNearByHospitalList(String lat, String lon) {
		// TODO Auto-generated method stub
		return null;
	}

	public TreeMap<String, Double> findNearByHelpersList(String lat, String lon) {
		
		/*
		 * 
		 * Search DB and find helpers with distance 1 km from lat lon
		 * Return the array List which contains "Name and PhoneNumber"
		 */
		
		return null;
	}

}
