package com.mercury.onAccident;

/***********************************************
 * 
 * 	Sends WebRtc Link to Users
 *  1. Helpers
 *  2. Hospital Agent
 * 
 ***********************************************/
public class InitiateCall {

	public int sendLink(String helper , String hospitalAgent){
		return 0;
		
	}
}
