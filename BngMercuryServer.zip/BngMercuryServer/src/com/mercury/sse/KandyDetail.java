package com.mercury.sse;

public class KandyDetail {

	
	String kandyUser="";
	public String getKandyUser() {
		return kandyUser;
	}
	public void setKandyUser(String kandyUser) {
		this.kandyUser = kandyUser;
	}
	public KandyDetail() {
		
		// TODO Auto-generated constructor stub
	}

}
